# Recipes/admin.py
from django.contrib import admin
from .models import Recipe, Comment


class RecipeAdmin(admin.ModelAdmin):
    list_display = ('title', 'ingredients', 'instructions', 'image', 'author')
    search_fields = ('title', 'author__username')


admin.site.register(Recipe, RecipeAdmin)
admin.site.register(Comment)


