# Recipes/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User

from .models import Recipe
from django import forms


class RecipeSearchForm(forms.Form):
    search_term = forms.CharField(max_length=100)


class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']


class CustomAuthenticationForm(AuthenticationForm):
    class Meta:
        model = User
        fields = ['username', 'password']


class RecipeForm(forms.ModelForm):
    # Adding a Textarea for dynamic input fields
    ingredients = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}), required=True)
    instructions = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}), required=True)

    class Meta:
        model = Recipe
        fields = ['title', 'ingredients', 'instructions', 'image']


from django import forms


class CommentForm(forms.Form):
    text = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), required=True)
