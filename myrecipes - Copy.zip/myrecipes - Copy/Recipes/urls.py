# Recipes/urls.py
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.urls import path, reverse_lazy
from django.contrib.auth.views import LoginView

from . import views, admin
from .views import signup, home, search, add_recipe, delete_recipe, update_recipe, add_comment, \
    like_recipe, dislike_recipe, custom_logout, About_view

def custom_logout(request):
    logout(request)
    return redirect('login_default')

urlpatterns = [

    path('', LoginView.as_view(template_name='registration/login.html'), name='login_default'),  # Use LoginView for the default page
    path('signup/', signup, name='signup'),
    path('home/', home, name='home'),
    path('search/', search, name='search'),
    path('recipe/<int:recipe_id>/', views.recipe_details, name='recipe_details'),
    path('add_recipe/', add_recipe, name='add_recipe'),
    path('delete_recipe/<int:recipe_id>/', delete_recipe, name='delete_recipe'),
    path('update_recipe/<int:recipe_id>/', update_recipe, name='update_recipe'),
    path('add_comment/<int:recipe_id>/', add_comment, name='add_comment'),
    path('like_recipe/<int:recipe_id>/', like_recipe, name='like_recipe'),
    path('dislike_recipe/<int:recipe_id>/', dislike_recipe, name='dislike_recipe'),
    path('about/', About_view, name='about'),


]

# Configure URL patterns for serving media files during development
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Configure URL patterns for serving static files during development
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
