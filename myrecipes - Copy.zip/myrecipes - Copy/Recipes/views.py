from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from pyexpat.errors import messages
from .forms import RecipeForm, RecipeSearchForm, CommentForm
from .models import Recipe, Comment


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})


from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Inside Recipes/views.py

# Inside Recipes/views.py
from django.contrib.auth.decorators import login_required


@login_required(login_url='login')
def home(request):
    # Get all recipes
    all_recipes = Recipe.objects.all()

    # Filter recipes uploaded by the logged-in user
    user_recipes = Recipe.objects.filter(author=request.user)

    # Paginate both sets of recipes


    return render(request, 'home.html', {'all_recipes': all_recipes, 'user_recipes': user_recipes, })


# Inside Recipes/views.py
from django.contrib.auth.decorators import login_required


@login_required(login_url='login')
def recipe_details(request, recipe_id):
    recipe = get_object_or_404(Recipe, pk=recipe_id)
    return render(request, 'recipe_details.html', {'recipe': recipe, 'user': request.user})


# Inside Recipes/views.py
# Inside Recipes/views.py

from django.shortcuts import render
from .forms import RecipeSearchForm
from .models import Recipe


from django.shortcuts import render
from .forms import RecipeSearchForm
from .models import Recipe

def search(request):
    form = RecipeSearchForm(request.GET)
    recipes = []

    if form.is_valid():
        search_term = form.cleaned_data['search_term']
        recipes = Recipe.objects.filter(title__icontains=search_term)

    return render(request, 'search.html', {'form': form, 'recipes': recipes})



@login_required
def add_recipe(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST, request.FILES)
        if form.is_valid():
            recipe = form.save(commit=False)
            recipe.author = request.user
            recipe.save()
            return redirect('home')
    else:
        form = RecipeForm()
    return render(request, 'add_recipe.html', {'form': form})


@login_required
def delete_recipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, pk=recipe_id)

    if request.user == recipe.author:
        recipe.delete()
        return redirect('home')
    else:
        messages.error(request, "You don't have permission to delete this recipe.")
        return redirect('home')


@login_required
def update_recipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, pk=recipe_id)

    if request.user != recipe.author:
        return HttpResponseForbidden("You don't have permission to update this recipe.")

    if request.method == 'POST':
        form = RecipeForm(request.POST, request.FILES, instance=recipe)
        if form.is_valid():
            form.save()
            return redirect('recipe_details', recipe_id=recipe.id)
    else:
        form = RecipeForm(instance=recipe)
    return render(request, 'update_recipe.html', {'form': form, 'recipe': recipe})


def like_recipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    user = request.user

    if user not in recipe.likes.all():
        recipe.likes.add(user)
        recipe.dislikes.remove(user)  # Remove user from dislikes if present
    else:
        return HttpResponseForbidden("You have already liked this recipe.")

    return redirect('recipe_details', recipe_id=recipe.id)

def dislike_recipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    user = request.user

    if user not in recipe.dislikes.all():
        recipe.dislikes.add(user)
        recipe.likes.remove(user)  # Remove user from likes if present
    else:
        return HttpResponseForbidden("You have already disliked this recipe.")

    return redirect('recipe_details', recipe_id=recipe.id)

@login_required
def add_comment(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data['text']
            comment = Comment.objects.create(user=request.user, recipe=recipe, text=text)
            return redirect('recipe_details', recipe_id=recipe.id)
    else:
        form = CommentForm()

    return render(request, 'add_comment.html', {'form': form, 'recipe': recipe})


def custom_logout(request):
    logout(request)
    return redirect('login_default')

from django.shortcuts import render

def About_view(request):
    return render(request, 'About.html')  # Replace 'about.html' with the actual template name.

